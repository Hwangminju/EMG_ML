# emg_ML

Machine Learning with EMG Data
